<?php include("header.inc"); ?> 
<?php include("nav.inc"); ?> 

<h2 style="text-align:center;">Enhancements Showcase</h2>

<div style="display:flex; justify-content:space-around; margin:20px;">
    <div style="width:150px; height:150px; background-color:#FFCCCC; border:1px solid #999; text-align:center; line-height:150px;">
        Box 1
    </div>
    <div style="width:150px; height:150px; background-color:#CCFFCC; border:1px solid #999; text-align:center; line-height:150px;">
        Box 2
    </div>
    <div style="width:150px; height:150px; background-color:#CCCCFF; border:1px solid #999; text-align:center; line-height:150px;">
        Box 3
    </div>
</div>

<?php include("footer.inc"); ?>
