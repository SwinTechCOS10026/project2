<?php
$host = "127.0.0.1";
$user = "webuser";
$pwd = "supersecret"; 
$sql_db = "swintech"; 
?>